import Countries from "./components/Countries";
import { getAllCountries } from "./service";



getAllCountries().then(res=>{
    let countries = res.data
    console.log(countries[0]);
    document.querySelector('main').append(...Countries(countries)) 

})